import { forwardRef, useState } from 'react';
import { PassportData } from '../App';

interface Props {
  data: PassportData;
}

function formatDate(dateStr: string): string {
  if (!dateStr) return '__.__.____';
  const [year, month, day] = dateStr.split('-');
  return `${day}.${month}.${year}`;
}

const PassportPreview = forwardRef<HTMLDivElement, Props>(({ data }, ref) => {
  const [page, setPage] = useState<1 | 2>(1);
  const [passportType, setPassportType] = useState<'internal' | 'international'>('internal');

  return (
    <div ref={ref} className="flex flex-col items-center gap-4">
      {/* Passport Type Switcher */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        <button
          onClick={() => setPassportType('internal')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
            passportType === 'internal'
              ? 'bg-amber-500/20 text-amber-200 border border-amber-500/30'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          📘 Внутренний
        </button>
        <button
          onClick={() => setPassportType('international')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
            passportType === 'international'
              ? 'bg-blue-500/20 text-blue-200 border border-blue-500/30'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          🌍 Загранпаспорт
        </button>
      </div>

      {/* Page Switcher (only for internal passport) */}
      {passportType === 'internal' && (
        <div className="flex gap-2">
          <button
            onClick={() => setPage(1)}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
              page === 1
                ? 'bg-blue-500/30 text-blue-200 border border-blue-500/40'
                : 'bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10'
            }`}
          >
            Стр. 1 — Фото
          </button>
          <button
            onClick={() => setPage(2)}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
              page === 2
                ? 'bg-blue-500/30 text-blue-200 border border-blue-500/40'
                : 'bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10'
            }`}
          >
            Стр. 2 — Регистрация
          </button>
        </div>
      )}

      {passportType === 'internal' ? (
        page === 1 ? <PassportPage1 data={data} /> : <PassportPage2 data={data} />
      ) : (
        <InternationalPassport data={data} />
      )}
    </div>
  );
});

// Страница 1 - Фото и основные данные (внутренний паспорт)
const PassportPage1 = ({ data }: { data: PassportData }) => (
  <div className="w-full max-w-[500px] bg-gradient-to-b from-amber-50 to-amber-100 rounded-lg shadow-2xl overflow-hidden border border-amber-200 relative">
    {/* Watermark */}
    <div className="absolute inset-0 opacity-[0.03] pointer-events-none">
      <div className="absolute inset-0" style={{
        backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 35px, rgba(139,69,19,0.3) 35px, rgba(139,69,19,0.3) 36px)`,
      }}></div>
    </div>

    {/* Header */}
    <div className="relative bg-gradient-to-r from-amber-800 via-amber-700 to-amber-800 px-6 py-4 text-center">
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='0.3' fill-rule='evenodd'%3E%3Cpath d='M0 40L40 0H20L0 20M40 40V20L20 40'/%3E%3C/g%3E%3C/svg%3E")`,
      }}></div>
      <div className="relative">
        <div className="flex items-center justify-center gap-3 mb-1">
          <div className="w-6 h-4 rounded-sm overflow-hidden shadow-sm">
            <div className="w-full h-full" style={{
              backgroundImage: `linear-gradient(to bottom, #fff 0%, #fff 33%, #0039A6 33%, #0039A6 66%, #D52B1E 66%, #D52B1E 100%)`,
            }}></div>
          </div>
          <span className="text-amber-100 font-bold text-lg tracking-wider">РОССИЙСКАЯ ФЕДЕРАЦИЯ</span>
          <div className="w-6 h-4 rounded-sm overflow-hidden shadow-sm">
            <div className="w-full h-full" style={{
              backgroundImage: `linear-gradient(to bottom, #fff 0%, #fff 33%, #0039A6 33%, #0039A6 66%, #D52B1E 66%, #D52B1E 100%)`,
            }}></div>
          </div>
        </div>
        <p className="text-amber-200 text-sm font-medium tracking-wider">✦ ПАСПОРТ ГРАЖДАНИНА ✦</p>
      </div>
    </div>

    {/* Content */}
    <div className="p-6 relative">
      <div className="flex gap-5 mb-6">
        {/* Photo */}
        <div className="flex-shrink-0">
          <div className="w-[115px] h-[145px] border-2 border-amber-400/60 rounded-md overflow-hidden bg-white flex items-center justify-center shadow-inner relative">
            {data.photo ? (
              <img src={data.photo} alt="Фото" className="w-full h-full object-cover" />
            ) : (
              <div className="text-center">
                <span className="text-5xl opacity-30">👤</span>
                <p className="text-[10px] text-gray-400 mt-2">35×45 мм</p>
              </div>
            )}
            {/* Corner decorations */}
            <div className="absolute top-1 left-1 w-3 h-3 border-t-2 border-l-2 border-amber-400/40"></div>
            <div className="absolute top-1 right-1 w-3 h-3 border-t-2 border-r-2 border-amber-400/40"></div>
            <div className="absolute bottom-1 left-1 w-3 h-3 border-b-2 border-l-2 border-amber-400/40"></div>
            <div className="absolute bottom-1 right-1 w-3 h-3 border-b-2 border-r-2 border-amber-400/40"></div>
          </div>
        </div>

        {/* Main info */}
        <div className="flex-1 space-y-2">
          <div>
            <p className="text-[10px] text-amber-700/60 uppercase tracking-wider font-medium">Фамилия</p>
            <p className="text-[15px] font-bold text-gray-800 border-b border-amber-300/50 pb-0.5 min-h-[22px]">
              {data.lastName || '_______________'}
            </p>
          </div>
          <div>
            <p className="text-[10px] text-amber-700/60 uppercase tracking-wider font-medium">Имя</p>
            <p className="text-[15px] font-bold text-gray-800 border-b border-amber-300/50 pb-0.5 min-h-[22px]">
              {data.firstName || '_______________'}
            </p>
          </div>
          <div>
            <p className="text-[10px] text-amber-700/60 uppercase tracking-wider font-medium">Отчество</p>
            <p className="text-[15px] font-bold text-gray-800 border-b border-amber-300/50 pb-0.5 min-h-[22px]">
              {data.middleName || '_______________'}
            </p>
          </div>
          <div>
            <p className="text-[10px] text-amber-700/60 uppercase tracking-wider font-medium">Пол</p>
            <p className="text-[15px] font-bold text-gray-800 border-b border-amber-300/50 pb-0.5">
              {data.gender === 'male' ? 'МУЖ.' : 'ЖЕН.'}
            </p>
          </div>
        </div>
      </div>

      {/* Additional info */}
      <div className="space-y-2">
        <div>
          <p className="text-[10px] text-amber-700/60 uppercase tracking-wider font-medium">Дата рождения</p>
          <p className="text-[15px] font-bold text-gray-800 border-b border-amber-300/50 pb-0.5">
            {formatDate(data.birthDate)}
          </p>
        </div>
        <div>
          <p className="text-[10px] text-amber-700/60 uppercase tracking-wider font-medium">Место рождения</p>
          <p className="text-sm text-gray-800 border-b border-amber-300/50 pb-0.5">
            {data.birthPlace || '_______________'}
          </p>
        </div>
      </div>
    </div>

    {/* Footer */}
    <div className="bg-gradient-to-r from-amber-800 via-amber-700 to-amber-800 px-6 py-2 text-center">
      <p className="text-amber-200 text-[10px] tracking-wider">МВД РОССИИ</p>
    </div>

    {/* Demo watermark */}
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
      <div className="transform -rotate-[15deg] opacity-[0.06]">
        <p className="text-6xl font-black text-red-900 tracking-[0.3em]">ДЕМО</p>
      </div>
    </div>
  </div>
);

// Страница 2 - Регистрация и данные выдачи
const PassportPage2 = ({ data }: { data: PassportData }) => (
  <div className="w-full max-w-[500px] bg-gradient-to-b from-amber-50 to-amber-100 rounded-lg shadow-2xl overflow-hidden border border-amber-200 relative">
    {/* Watermark */}
    <div className="absolute inset-0 opacity-[0.03] pointer-events-none">
      <div className="absolute inset-0" style={{
        backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 35px, rgba(139,69,19,0.3) 35px, rgba(139,69,19,0.3) 36px)`,
      }}></div>
    </div>

    {/* Header */}
    <div className="relative bg-gradient-to-r from-amber-800 via-amber-700 to-amber-800 px-6 py-3 text-center">
      <p className="text-amber-200 text-xs tracking-wider">ПАСПОРТ ГРАЖДАНИНА РОССИЙСКОЙ ФЕДЕРАЦИИ</p>
    </div>

    {/* Content */}
    <div className="p-6 relative space-y-4">
      {/* ФИО */}
      <div className="grid grid-cols-3 gap-3">
        <div>
          <p className="text-[10px] text-amber-700/60 uppercase tracking-wider font-medium">Фамилия</p>
          <p className="text-xs font-bold text-gray-800 border-b border-amber-300/50 pb-0.5">
            {data.lastName}
          </p>
        </div>
        <div>
          <p className="text-[10px] text-amber-700/60 uppercase tracking-wider font-medium">Имя</p>
          <p className="text-xs font-bold text-gray-800 border-b border-amber-300/50 pb-0.5">
            {data.firstName}
          </p>
        </div>
        <div>
          <p className="text-[10px] text-amber-700/60 uppercase tracking-wider font-medium">Отчество</p>
          <p className="text-xs font-bold text-gray-800 border-b border-amber-300/50 pb-0.5">
            {data.middleName}
          </p>
        </div>
      </div>

      <div className="border-t border-dashed border-amber-300"></div>

      {/* Registration */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <span className="text-sm">🏠</span>
          <p className="text-xs text-amber-700 font-semibold uppercase tracking-wider">Место регистрации</p>
        </div>
        <div className="bg-white/60 rounded-lg p-3 border border-amber-200/50 shadow-sm">
          <p className="text-sm text-gray-800">
            {data.registration || '_______________'}
          </p>
        </div>
      </div>

      <div className="border-t border-dashed border-amber-300"></div>

      {/* Issue info */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <span className="text-sm">📄</span>
          <p className="text-xs text-amber-700 font-semibold uppercase tracking-wider">Данные о выдаче паспорта</p>
        </div>
        <div className="space-y-2">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="text-[10px] text-amber-700/60 uppercase tracking-wider font-medium">Серия и номер</p>
              <p className="text-xs font-bold text-gray-800 border-b border-amber-300/50 pb-0.5">
                {data.series} № {data.number}
              </p>
            </div>
            <div>
              <p className="text-[10px] text-amber-700/60 uppercase tracking-wider font-medium">Дата выдачи</p>
              <p className="text-xs font-bold text-gray-800 border-b border-amber-300/50 pb-0.5">
                {formatDate(data.issueDate)}
              </p>
            </div>
          </div>
          <div>
            <p className="text-[10px] text-amber-700/60 uppercase tracking-wider font-medium">Кем выдан</p>
            <p className="text-xs text-gray-800 border-b border-amber-300/50 pb-0.5">
              {data.issuedBy || '_______________'}
            </p>
          </div>
          <div>
            <p className="text-[10px] text-amber-700/60 uppercase tracking-wider font-medium">Код подразделения</p>
            <p className="text-xs font-bold text-gray-800 border-b border-amber-300/50 pb-0.5">
              {data.departmentCode || '___-___'}
            </p>
          </div>
        </div>
      </div>

      <div className="border-t border-dashed border-amber-300"></div>

      {/* Signature */}
      <div className="flex items-end justify-between pt-2">
        <div>
          <p className="text-[10px] text-amber-700/60 uppercase tracking-wider font-medium">Подпись владельца</p>
          <div className="w-40 h-10 border-b border-amber-300/50 flex items-end justify-center pb-1">
            <span className="text-gray-500 text-sm italic" style={{ fontFamily: 'cursive' }}>
              {data.lastName.charAt(0)}. {data.firstName.charAt(0)}.
            </span>
          </div>
        </div>
        <div className="text-right">
          <div className="w-16 h-16 rounded-full border-2 border-amber-300/40 flex items-center justify-center bg-white/40">
            <div className="w-12 h-12 rounded-full border border-amber-300/30 flex items-center justify-center">
              <span className="text-xl">🔏</span>
            </div>
          </div>
          <p className="text-[9px] text-amber-700/50 mt-1">М.П.</p>
        </div>
      </div>
    </div>

    {/* Footer */}
    <div className="bg-gradient-to-r from-amber-800 via-amber-700 to-amber-800 px-6 py-2 text-center">
      <p className="text-amber-200 text-[10px] tracking-wider">МИНИСТЕРСТВО ВНУТРЕННИХ ДЕЛ РОССИЙСКОЙ ФЕДЕРАЦИИ</p>
    </div>

    {/* Demo watermark */}
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
      <div className="transform -rotate-[15deg] opacity-[0.06]">
        <p className="text-6xl font-black text-red-900 tracking-[0.3em]">ДЕМО</p>
      </div>
    </div>
  </div>
);

// Загранпаспорт
const InternationalPassport = ({ data }: { data: PassportData }) => {
  const transliterate = (text: string): string => {
    const map: Record<string, string> = {
      'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'e',
      'ж': 'zh', 'з': 'z', 'и': 'i', 'й': 'i', 'к': 'k', 'л': 'l', 'м': 'm',
      'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u',
      'ф': 'f', 'х': 'kh', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'щ': 'sch',
      'ъ': '', 'ы': 'y', 'ь': '', 'э': 'e', 'ю': 'iu', 'я': 'ia',
      'А': 'A', 'Б': 'B', 'В': 'V', 'Г': 'G', 'Д': 'D', 'Е': 'E', 'Ё': 'E',
      'Ж': 'ZH', 'З': 'Z', 'И': 'I', 'Й': 'I', 'К': 'K', 'Л': 'L', 'М': 'M',
      'Н': 'N', 'О': 'O', 'П': 'P', 'Р': 'R', 'С': 'S', 'Т': 'T', 'У': 'U',
      'Ф': 'F', 'Х': 'KH', 'Ц': 'TS', 'Ч': 'CH', 'Ш': 'SH', 'Щ': 'SCH',
      'Ъ': '', 'Ы': 'Y', 'Ь': '', 'Э': 'E', 'Ю': 'IU', 'Я': 'IA',
    };
    return text.split('').map(c => map[c] || c).join('');
  };

  return (
    <div className="w-full max-w-[500px] bg-gradient-to-b from-blue-50 to-blue-100 rounded-lg shadow-2xl overflow-hidden border border-blue-200 relative">
      {/* Watermark */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 35px, rgba(0,0,139,0.3) 35px, rgba(0,0,139,0.3) 36px)`,
        }}></div>
      </div>

      {/* Header */}
      <div className="relative bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 px-6 py-4 text-center">
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='0.3' fill-rule='evenodd'%3E%3Cpath d='M0 40L40 0H20L0 20M40 40V20L20 40'/%3E%3C/g%3E%3C/svg%3E")`,
        }}></div>
        <div className="relative">
          <p className="text-blue-200 text-[10px] tracking-widest uppercase mb-1">Russian Federation</p>
          <div className="flex items-center justify-center gap-2 mb-1">
            <span className="text-white font-bold text-lg tracking-wider">РОССИЙСКАЯ ФЕДЕРАЦИЯ</span>
          </div>
          <p className="text-blue-200 text-sm font-medium tracking-wider">✦ ПАСПОРТ / PASSPORT ✦</p>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 relative">
        <div className="flex gap-5 mb-6">
          {/* Photo */}
          <div className="flex-shrink-0">
            <div className="w-[115px] h-[145px] border-2 border-blue-300/60 rounded-md overflow-hidden bg-white flex items-center justify-center shadow-inner relative">
              {data.photo ? (
                <img src={data.photo} alt="Фото" className="w-full h-full object-cover" />
              ) : (
                <div className="text-center">
                  <span className="text-5xl opacity-30">👤</span>
                  <p className="text-[10px] text-gray-400 mt-2">Фото</p>
                </div>
              )}
            </div>
          </div>

          {/* Info */}
          <div className="flex-1 space-y-1.5">
            <div>
              <p className="text-[10px] text-blue-700/60 uppercase tracking-wider font-medium">Фамилия / Surname</p>
              <p className="text-[13px] font-bold text-gray-800 border-b border-blue-300/50 pb-0.5">
                {data.lastName}
              </p>
              <p className="text-[10px] text-blue-600/60 italic">{transliterate(data.lastName)}</p>
            </div>
            <div>
              <p className="text-[10px] text-blue-700/60 uppercase tracking-wider font-medium">Имя / Name</p>
              <p className="text-[13px] font-bold text-gray-800 border-b border-blue-300/50 pb-0.5">
                {data.firstName}
              </p>
              <p className="text-[10px] text-blue-600/60 italic">{transliterate(data.firstName)}</p>
            </div>
            <div>
              <p className="text-[10px] text-blue-700/60 uppercase tracking-wider font-medium">Гражданство / Nationality</p>
              <p className="text-[13px] font-bold text-gray-800 border-b border-blue-300/50 pb-0.5">
                РОССИЙСКАЯ / RUSSIAN
              </p>
            </div>
          </div>
        </div>

        {/* Details */}
        <div className="grid grid-cols-2 gap-x-4 gap-y-2">
          <div>
            <p className="text-[10px] text-blue-700/60 uppercase tracking-wider font-medium">Дата рождения / Date of birth</p>
            <p className="text-xs font-bold text-gray-800 border-b border-blue-300/50 pb-0.5">
              {formatDate(data.birthDate)}
            </p>
          </div>
          <div>
            <p className="text-[10px] text-blue-700/60 uppercase tracking-wider font-medium">Пол / Sex</p>
            <p className="text-xs font-bold text-gray-800 border-b border-blue-300/50 pb-0.5">
              {data.gender === 'male' ? 'М / M' : 'Ж / F'}
            </p>
          </div>
          <div>
            <p className="text-[10px] text-blue-700/60 uppercase tracking-wider font-medium">Место рождения / Place of birth</p>
            <p className="text-xs text-gray-800 border-b border-blue-300/50 pb-0.5">
              {data.birthPlace}
            </p>
          </div>
          <div>
            <p className="text-[10px] text-blue-700/60 uppercase tracking-wider font-medium">Дата выдачи / Date of issue</p>
            <p className="text-xs font-bold text-gray-800 border-b border-blue-300/50 pb-0.5">
              {formatDate(data.issueDate)}
            </p>
          </div>
          <div>
            <p className="text-[10px] text-blue-700/60 uppercase tracking-wider font-medium">Номер / Number</p>
            <p className="text-xs font-bold text-gray-800 border-b border-blue-300/50 pb-0.5">
              № {data.number}
            </p>
          </div>
          <div>
            <p className="text-[10px] text-blue-700/60 uppercase tracking-wider font-medium">Орган выдачи / Authority</p>
            <p className="text-xs text-gray-800 border-b border-blue-300/50 pb-0.5 truncate">
              {data.issuedBy}
            </p>
          </div>
        </div>
      </div>

      {/* MRZ Zone */}
      <div className="bg-gray-100 border-t-2 border-blue-200 px-4 py-3">
        <p className="text-[9px] font-mono text-gray-700 tracking-wider leading-relaxed">
          P&lt;RUS{transliterate(data.lastName).toUpperCase()}&lt;&lt;{transliterate(data.firstName).toUpperCase()}&lt;{transliterate(data.middleName).toUpperCase()}
        </p>
        <p className="text-[9px] font-mono text-gray-700 tracking-wider leading-relaxed">
          {data.number}{'<'}7RUS{data.birthDate.replace(/-/g, '').slice(2)}{data.gender === 'male' ? 'M' : 'F'}
          {'<'}{'<'}{'<'}{'<'}{'<'}{'<'}{'<'}{'<'}{'<'}0
        </p>
      </div>

      {/* Footer */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 px-6 py-2 text-center">
        <p className="text-blue-200 text-[10px] tracking-wider">МИНИСТЕРСТВО ИНОСТРАННЫХ ДЕЛ РОССИЙСКОЙ ФЕДЕРАЦИИ</p>
      </div>

      {/* Demo watermark */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="transform -rotate-[15deg] opacity-[0.06]">
          <p className="text-6xl font-black text-blue-900 tracking-[0.3em]">ДЕМО</p>
        </div>
      </div>
    </div>
  );
};

PassportPreview.displayName = 'PassportPreview';

export default PassportPreview;
