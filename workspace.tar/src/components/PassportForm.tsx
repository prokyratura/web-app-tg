import { ChangeEvent, useRef, useCallback } from 'react';
import { PassportData } from '../App';

interface Props {
  data: PassportData;
  onChange: (data: Partial<PassportData>) => void;
  onPhotoChange: (photo: string | null) => void;
}

// Генератор случайных данных
const randomNames = {
  male: {
    lastNames: ['Иванов', 'Петров', 'Сидоров', 'Козлов', 'Новиков', 'Морозов', 'Волков', 'Соловьёв', 'Васильев', 'Зайцев'],
    firstNames: ['Александр', 'Дмитрий', 'Максим', 'Сергей', 'Андрей', 'Алексей', 'Артём', 'Илья', 'Кирилл', 'Михаил'],
    middleNames: ['Александрович', 'Дмитриевич', 'Сергеевич', 'Андреевич', 'Иванович', 'Николаевич', 'Владимирович', 'Петрович'],
  },
  female: {
    lastNames: ['Иванова', 'Петрова', 'Сидорова', 'Козлова', 'Новикова', 'Морозова', 'Волкова', 'Соловьёва', 'Васильева', 'Зайцева'],
    firstNames: ['Анна', 'Мария', 'Елена', 'Дарья', 'Алиса', 'Екатерина', 'Софья', 'Полина', 'Виктория', 'Ольга'],
    middleNames: ['Александровна', 'Дмитриевна', 'Сергеевна', 'Андреевна', 'Ивановна', 'Николаевна', 'Владимировна', 'Петровна'],
  }
};

const cities = ['г. Москва', 'г. Санкт-Петербург', 'г. Новосибирск', 'г. Екатеринбург', 'г. Казань', 'г. Нижний Новгород', 'г. Челябинск', 'г. Самара', 'г. Омск', 'г. Ростов-на-Дону'];
const streets = ['ул. Ленина', 'ул. Пушкина', 'ул. Гагарина', 'пр. Мира', 'ул. Советская', 'ул. Кирова', 'ул. Московская', 'бул. Победы', 'ул. Садовая', 'ул. Центральная'];
const departments = ['ОВД района Тверской г. Москвы', 'УМВД России по г. Казани', 'ОВД района Пресненский г. Москвы', 'УМВД по Новосибирской области', 'ОВД Центрального района г. Санкт-Петербурга'];

function generateRandomData(gender: 'male' | 'female'): Partial<PassportData> {
  const names = randomNames[gender];
  const lastName = names.lastNames[Math.floor(Math.random() * names.lastNames.length)];
  const firstName = names.firstNames[Math.floor(Math.random() * names.firstNames.length)];
  const middleName = names.middleNames[Math.floor(Math.random() * names.middleNames.length)];
  const city = cities[Math.floor(Math.random() * cities.length)];
  const street = streets[Math.floor(Math.random() * streets.length)];
  const house = Math.floor(Math.random() * 150) + 1;
  const apt = Math.floor(Math.random() * 200) + 1;
  const dept = departments[Math.floor(Math.random() * departments.length)];

  const birthYear = Math.floor(Math.random() * 40) + 1960;
  const birthMonth = Math.floor(Math.random() * 12) + 1;
  const birthDay = Math.floor(Math.random() * 28) + 1;

  const issueYear = Math.floor(Math.random() * 10) + 2015;
  const issueMonth = Math.floor(Math.random() * 12) + 1;
  const issueDay = Math.floor(Math.random() * 28) + 1;

  const series = String(Math.floor(Math.random() * 9000) + 1000);
  const number = String(Math.floor(Math.random() * 900000) + 100000);
  const deptCode = `${Math.floor(Math.random() * 900) + 100}-${String(Math.floor(Math.random() * 900) + 100).slice(0, 3)}`;

  return {
    lastName,
    firstName,
    middleName,
    gender,
    birthDate: `${birthYear}-${String(birthMonth).padStart(2, '0')}-${String(birthDay).padStart(2, '0')}`,
    birthPlace: city,
    series,
    number,
    issueDate: `${issueYear}-${String(issueMonth).padStart(2, '0')}-${String(issueDay).padStart(2, '0')}`,
    issuedBy: dept,
    departmentCode: deptCode,
    registration: `${city}, ${street}, д. ${house}, кв. ${apt}`,
  };
}

export default function PassportForm({ data, onChange, onPhotoChange }: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    onChange({ [name]: value });
  };

  const handleRandomize = useCallback(() => {
    const randomData = generateRandomData(data.gender);
    onChange(randomData);
  }, [data.gender, onChange]);

  const handlePhotoUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        onPhotoChange(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    onPhotoChange(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-white flex items-center gap-2">
          <span className="text-2xl">📋</span>
          Данные паспорта
        </h2>
        <button
          onClick={handleRandomize}
          className="flex items-center gap-2 px-3 py-1.5 bg-purple-500/20 border border-purple-500/30 rounded-lg text-purple-300 text-sm hover:bg-purple-500/30 transition-colors"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          Случайные
        </button>
      </div>

      <div className="space-y-6">
        {/* Photo Upload */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Фотография</label>
          <div className="flex items-center gap-4">
            {data.photo ? (
              <div className="relative">
                <img
                  src={data.photo}
                  alt="Фото"
                  className="w-20 h-28 object-cover rounded-lg border-2 border-white/20"
                />
                <button
                  onClick={handleRemovePhoto}
                  className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-white text-xs hover:bg-red-600 transition-colors"
                >
                  ✕
                </button>
              </div>
            ) : (
              <div className="w-20 h-28 bg-white/10 rounded-lg border-2 border-dashed border-white/20 flex items-center justify-center">
                <span className="text-gray-500 text-2xl">👤</span>
              </div>
            )}
            <label className="cursor-pointer px-4 py-2 bg-blue-500/20 border border-blue-500/30 rounded-lg text-blue-300 text-sm hover:bg-blue-500/30 transition-colors">
              Загрузить фото
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />
            </label>
          </div>
        </div>

        {/* ФИО */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Фамилия</label>
            <input
              type="text"
              name="lastName"
              value={data.lastName}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
              placeholder="Иванов"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Имя</label>
            <input
              type="text"
              name="firstName"
              value={data.firstName}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
              placeholder="Иван"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Отчество</label>
            <input
              type="text"
              name="middleName"
              value={data.middleName}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
              placeholder="Иванович"
            />
          </div>
        </div>

        {/* Пол и дата рождения */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Пол</label>
            <select
              name="gender"
              value={data.gender}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
            >
              <option value="male" className="bg-slate-800">Мужской</option>
              <option value="female" className="bg-slate-800">Женский</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Дата рождения</label>
            <input
              type="date"
              name="birthDate"
              value={data.birthDate}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
            />
          </div>
        </div>

        {/* Место рождения */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-1">Место рождения</label>
          <input
            type="text"
            name="birthPlace"
            value={data.birthPlace}
            onChange={handleChange}
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
            placeholder="г. Москва"
          />
        </div>

        {/* Серия и номер */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Серия</label>
            <input
              type="text"
              name="series"
              value={data.series}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
              placeholder="4510"
              maxLength={4}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Номер</label>
            <input
              type="text"
              name="number"
              value={data.number}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
              placeholder="123456"
              maxLength={6}
            />
          </div>
        </div>

        {/* Дата выдачи */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-1">Дата выдачи</label>
          <input
            type="date"
            name="issueDate"
            value={data.issueDate}
            onChange={handleChange}
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
          />
        </div>

        {/* Кем выдан */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-1">Кем выдан</label>
          <input
            type="text"
            name="issuedBy"
            value={data.issuedBy}
            onChange={handleChange}
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
            placeholder="ОВД района..."
          />
        </div>

        {/* Код подразделения */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-1">Код подразделения</label>
          <input
            type="text"
            name="departmentCode"
            value={data.departmentCode}
            onChange={handleChange}
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
            placeholder="770-001"
          />
        </div>

        {/* Регистрация */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-1">Место регистрации</label>
          <textarea
            name="registration"
            value={data.registration}
            onChange={handleChange}
            rows={2}
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all resize-none"
            placeholder="г. Москва, ул. ..."
          />
        </div>
      </div>
    </div>
  );
}
