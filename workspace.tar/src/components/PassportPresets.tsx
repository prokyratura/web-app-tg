import { PassportData } from '../App';

interface Props {
  onSelect: (data: Partial<PassportData>) => void;
}

interface Preset {
  name: string;
  emoji: string;
  description: string;
  data: Partial<PassportData>;
}

const presets: Preset[] = [
  {
    name: 'Москвич',
    emoji: '🏙️',
    description: 'Типичный житель Москвы',
    data: {
      lastName: 'Иванов',
      firstName: 'Александр',
      middleName: 'Сергеевич',
      gender: 'male',
      birthDate: '1985-06-15',
      birthPlace: 'г. Москва',
      series: '4510',
      number: '234567',
      issueDate: '2020-03-15',
      issuedBy: 'ОВД района Тверской г. Москвы',
      departmentCode: '770-001',
      registration: 'г. Москва, ул. Тверская, д. 15, кв. 42',
    },
  },
  {
    name: 'Студентка',
    emoji: '👩‍🎓',
    description: 'Студентка из Петербурга',
    data: {
      lastName: 'Петрова',
      firstName: 'Анна',
      middleName: 'Дмитриевна',
      gender: 'female',
      birthDate: '2001-09-23',
      birthPlace: 'г. Санкт-Петербург',
      series: '4005',
      number: '789012',
      issueDate: '2021-10-01',
      issuedBy: 'УМВД России по Центральному району г. Санкт-Петербурга',
      departmentCode: '780-005',
      registration: 'г. Санкт-Петербург, Невский пр., д. 28, кв. 7',
    },
  },
  {
    name: 'Предприниматель',
    emoji: '💼',
    description: 'Бизнесмен из Казани',
    data: {
      lastName: 'Мухаметшин',
      firstName: 'Ринат',
      middleName: 'Альбертович',
      gender: 'male',
      birthDate: '1978-03-10',
      birthPlace: 'г. Казань',
      series: '9215',
      number: '456789',
      issueDate: '2018-05-20',
      issuedBy: 'УМВД России по г. Казани',
      departmentCode: '160-003',
      registration: 'Республика Татарстан, г. Казань, ул. Баумана, д. 36, кв. 15',
    },
  },
  {
    name: 'Пенсионер',
    emoji: '👴',
    description: 'Пенсионер из Новосибирска',
    data: {
      lastName: 'Сидоров',
      firstName: 'Виктор',
      middleName: 'Николаевич',
      gender: 'male',
      birthDate: '1955-11-07',
      birthPlace: 'г. Новосибирск',
      series: '5001',
      number: '112233',
      issueDate: '2015-08-12',
      issuedBy: 'УМВД России по Новосибирской области',
      departmentCode: '540-001',
      registration: 'г. Новосибирск, ул. Ленина, д. 22, кв. 5',
    },
  },
  {
    name: 'Учительница',
    emoji: '👩‍🏫',
    description: 'Школьный учитель',
    data: {
      lastName: 'Козлова',
      firstName: 'Елена',
      middleName: 'Владимировна',
      gender: 'female',
      birthDate: '1982-04-18',
      birthPlace: 'г. Екатеринбург',
      series: '6510',
      number: '334455',
      issueDate: '2019-02-28',
      issuedBy: 'ОВД Верх-Исетского района г. Екатеринбурга',
      departmentCode: '660-008',
      registration: 'г. Екатеринбург, ул. Малышева, д. 78, кв. 23',
    },
  },
  {
    name: 'Спортсмен',
    emoji: '🏃',
    description: 'Молодой спортсмен',
    data: {
      lastName: 'Волков',
      firstName: 'Дмитрий',
      middleName: 'Андреевич',
      gender: 'male',
      birthDate: '1998-07-22',
      birthPlace: 'г. Самара',
      series: '3612',
      number: '667788',
      issueDate: '2022-01-15',
      issuedBy: 'ОВД Октябрьского района г. Самары',
      departmentCode: '630-012',
      registration: 'г. Самара, ул. Молодогвардейская, д. 155, кв. 89',
    },
  },
];

export default function PassportPresets({ onSelect }: Props) {
  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-6">
      <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
        <span className="text-2xl">🎭</span>
        Шаблоны
      </h2>
      <p className="text-gray-400 text-sm mb-4">
        Выберите готовый шаблон для быстрого заполнения
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {presets.map((preset, index) => (
          <button
            key={index}
            onClick={() => onSelect(preset.data)}
            className="flex items-center gap-3 p-3 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 hover:border-white/20 transition-all text-left group"
          >
            <span className="text-2xl group-hover:scale-110 transition-transform">
              {preset.emoji}
            </span>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{preset.name}</p>
              <p className="text-xs text-gray-400 truncate">{preset.description}</p>
            </div>
            <svg className="w-4 h-4 text-gray-500 group-hover:text-blue-400 transition-colors flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        ))}
      </div>
    </div>
  );
}
