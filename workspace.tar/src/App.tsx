import { useState, useRef } from 'react';
import PassportForm from './components/PassportForm';
import PassportPreview from './components/PassportPreview';
import PassportExport from './components/PassportExport';
import PassportPresets from './components/PassportPresets';

export interface PassportData {
  lastName: string;
  firstName: string;
  middleName: string;
  gender: 'male' | 'female';
  birthDate: string;
  birthPlace: string;
  series: string;
  number: string;
  issueDate: string;
  issuedBy: string;
  departmentCode: string;
  registration: string;
  photo: string | null;
}

function App() {
  const [passportData, setPassportData] = useState<PassportData>({
    lastName: 'Иванов',
    firstName: 'Иван',
    middleName: 'Иванович',
    gender: 'male',
    birthDate: '1990-01-15',
    birthPlace: 'г. Москва',
    series: '4510',
    number: '123456',
    issueDate: '2020-03-20',
    issuedBy: 'ОВД района Тверской г. Москвы',
    departmentCode: '770-001',
    registration: 'г. Москва, ул. Тверская, д. 1, кв. 1',
    photo: null,
  });

  const [activeTab, setActiveTab] = useState<'form' | 'presets' | 'preview'>('form');
  const previewRef = useRef<HTMLDivElement>(null);

  const handleDataChange = (data: Partial<PassportData>) => {
    setPassportData(prev => ({ ...prev, ...data }));
  };

  const handlePhotoChange = (photo: string | null) => {
    setPassportData(prev => ({ ...prev, photo }));
  };

  const handlePresetSelect = (data: Partial<PassportData>) => {
    setPassportData(prev => ({ ...prev, ...data }));
    setActiveTab('preview');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      {/* Header */}
      <header className="border-b border-white/10 backdrop-blur-sm bg-white/5">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-red-700 rounded-lg flex items-center justify-center shadow-lg shadow-red-500/20">
              <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Генератор паспортов</h1>
              <p className="text-xs text-blue-300">Создание паспортов для демонстрации</p>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-3">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-lg border border-white/10">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-xs text-gray-300">Готов к работе</span>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Tab Switcher */}
      <div className="lg:hidden flex border-b border-white/10 bg-white/5">
        <button
          onClick={() => setActiveTab('form')}
          className={`flex-1 py-3 text-sm font-medium transition-colors ${
            activeTab === 'form'
              ? 'text-white border-b-2 border-blue-400 bg-white/5'
              : 'text-gray-400'
          }`}
        >
          📝 Данные
        </button>
        <button
          onClick={() => setActiveTab('presets')}
          className={`flex-1 py-3 text-sm font-medium transition-colors ${
            activeTab === 'presets'
              ? 'text-white border-b-2 border-blue-400 bg-white/5'
              : 'text-gray-400'
          }`}
        >
          🎭 Шаблоны
        </button>
        <button
          onClick={() => setActiveTab('preview')}
          className={`flex-1 py-3 text-sm font-medium transition-colors ${
            activeTab === 'preview'
              ? 'text-white border-b-2 border-blue-400 bg-white/5'
              : 'text-gray-400'
          }`}
        >
          👁 Превью
        </button>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column - Form & Presets */}
          <div className={`space-y-6 ${activeTab === 'preview' ? 'hidden lg:block' : ''}`}>
            {/* Presets */}
            <div className={`${activeTab === 'presets' ? 'block' : 'hidden'} lg:block`}>
              <PassportPresets onSelect={handlePresetSelect} />
            </div>

            {/* Form */}
            <div className={`${activeTab === 'form' ? 'block' : 'hidden'} lg:block`}>
              <PassportForm
                data={passportData}
                onChange={handleDataChange}
                onPhotoChange={handlePhotoChange}
              />
            </div>
          </div>

          {/* Right Column - Preview */}
          <div className={`${activeTab === 'preview' ? 'block' : 'hidden'} lg:block`}>
            <div className="sticky top-6 space-y-4">
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                    <span>👁</span> Превью паспорта
                  </h2>
                  <PassportExport previewRef={previewRef} />
                </div>
                <PassportPreview data={passportData} ref={previewRef} />
              </div>

              {/* Info Card */}
              <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20 rounded-xl p-4">
                <div className="flex gap-3">
                  <div className="text-blue-400 text-xl flex-shrink-0">ℹ️</div>
                  <div>
                    <p className="text-blue-200 text-sm font-medium">Для демонстрационных целей</p>
                    <p className="text-blue-300/70 text-xs mt-1">
                      Данный генератор создаёт визуальные макеты паспортов исключительно для образовательных и демонстрационных целей. Все данные вымышлены.
                    </p>
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
                  <p className="text-2xl font-bold text-white">2</p>
                  <p className="text-xs text-gray-400">Страницы</p>
                </div>
                <div className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
                  <p className="text-2xl font-bold text-white">12</p>
                  <p className="text-xs text-gray-400">Полей</p>
                </div>
                <div className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
                  <p className="text-2xl font-bold text-white">6</p>
                  <p className="text-xs text-gray-400">Шаблонов</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6 text-center">
          <p className="text-gray-500 text-sm">
            Генератор паспортов • Только для демонстрационных целей • 2024
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
